V-AGENT PORTABLE - Local AI Coding Agent
=========================================

SYSTEM REQUIREMENTS:
- Windows 10/11 64-bit
- Python 3.8+ (for GUI) - or use the .exe version
- Ollama installed and running

QUICK START:
1. Start Ollama:  ollama serve
2. Launch V-Agent:  V-Agent.exe  (command-line version)
3. Launch GUI:      start_gui.bat  (graphical version)

FIRST TIME SETUP:
1. Install Ollama from: https://ollama.com/download/windows
2. Pull a model:  ollama pull qwen2.5-coder:14b
3. Run V-Agent and follow the wizard

FILES:
- V-Agent.exe         Command-line agent (pre-compiled)
- GUI.py              Graphical interface (requires Python)
- start_gui.bat       Launcher for GUI
- vagent_config.json  Configuration (auto-generated)

NOTES:
- V-Agent is 100% local - no data leaves your machine
- Internet only needed for initial model download
- All conversations stay on your computer

SUPPORTED MODELS:
- qwen2.5-coder:14b (recommended, 8GB VRAM)
- qwen2.5-coder:7b  (lighter, 4GB VRAM)
- deepseek-coder-v2:16b (smarter, 9GB VRAM)
- codellama:13b
- granite-code:8b