@echo off
title V-Agent Terminal
echo Starting V-Agent...
echo.
echo Checking Ollama...
curl -s http://localhost:11434/api/tags >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Ollama is not running!
    echo Start Ollama with: ollama serve
    echo.
    pause
)
echo.
echo Launching V-Agent GUI...
pythonw GUI.py
echo.
echo GUI closed.
pause