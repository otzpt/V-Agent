@echo off
:: Navigate to repo root (scripts/ -> ../)
cd /d "%~dp0.."

title V-Agent Terminal

:: ── Find Python ──────────────────────────────────────────────────────────────
set PYTHON_CMD=

where pythonw >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=pythonw
    goto :python_found
)

python --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python
    goto :python_found
)

if exist "%LOCALAPPDATA%\Programs\Python\Python313\pythonw.exe" ( set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python313\pythonw.exe" & goto :python_found )
if exist "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe" ( set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe" & goto :python_found )
if exist "%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe" ( set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe" & goto :python_found )
if exist "%LOCALAPPDATA%\Programs\Python\Python310\pythonw.exe" ( set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python310\pythonw.exe" & goto :python_found )
if exist "%LOCALAPPDATA%\Programs\Python\Python39\pythonw.exe"  ( set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python39\pythonw.exe"  & goto :python_found )
if exist "C:\Python313\pythonw.exe" ( set PYTHON_CMD="C:\Python313\pythonw.exe" & goto :python_found )
if exist "C:\Python312\pythonw.exe" ( set PYTHON_CMD="C:\Python312\pythonw.exe" & goto :python_found )
if exist "C:\Python311\pythonw.exe" ( set PYTHON_CMD="C:\Python311\pythonw.exe" & goto :python_found )

echo.
echo [ERROR] Python not found.
echo Install from: https://www.python.org/downloads/
echo During install, tick "Add Python to PATH"
echo.
echo After installing, run:  pip install requests watchdog
echo.
pause
exit /b 1

:python_found
:: ── Check Ollama ─────────────────────────────────────────────────────────────
curl -s http://localhost:11434/api/tags >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Ollama not running. Start with: ollama serve
    echo.
)

:: ── Install missing dependencies silently ────────────────────────────────────
%PYTHON_CMD% -c "import requests" >nul 2>&1
if errorlevel 1 ( python -m pip install requests --quiet )

%PYTHON_CMD% -c "import tkinter" >nul 2>&1
if errorlevel 1 (
    echo [ERROR] tkinter missing. Reinstall Python with standard library enabled.
    pause
    exit /b 1
)

:: ── Launch GUI ────────────────────────────────────────────────────────────────
start "" %PYTHON_CMD% gui\GUI.py
