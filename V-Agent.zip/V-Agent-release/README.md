<div align="center">

```
  __     __         _
  \ \   / /        | |
   \ \_/ /   __ _  | |_    ___  _ __
    \   /   / _` | | __|  / _ \| '__|
    | |   | (_| | | |_  |  __/| |
    |_|    \__,_|  \__|  \___||_|
```

**V-Agent v0.4** — Local AI Coding Agent

[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](LICENSE)
[![Platform: Windows](https://img.shields.io/badge/Platform-Windows%2010%2F11-blue)](https://github.com)
[![Ollama](https://img.shields.io/badge/Powered%20by-Ollama-orange)](https://ollama.com)
[![Zero Telemetry](https://img.shields.io/badge/Telemetry-Zero-green)](https://github.com)

*100% local. Zero telemetry. Your code never leaves your machine.*

</div>

---

## What is V-Agent?

V-Agent is a local AI coding assistant that runs entirely on your hardware via [Ollama](https://ollama.com). It comes in two forms:

- **Terminal** (`bin/V-Agent.exe`) — full-featured CLI with project indexing, git integration, file editing, session persistence, and a first-run hardware wizard
- **GUI** (`gui/GUI.py`) — tkinter-based graphical terminal with the same AI chat, VOIDTUNE purple theme

No API keys. No internet after model download. No data sent anywhere.

---

## Requirements

| Requirement | Notes |
|---|---|
| Windows 10 / 11 (64-bit) | Required |
| [Ollama](https://ollama.com/download/windows) | Must be running (`ollama serve`) |
| Python 3.9+ | Required for GUI only — install from [python.org](https://www.python.org/downloads/), **not** Microsoft Store |
| `requests` pip package | Auto-installed by `start_gui.bat` if missing |

> **Note:** When installing Python, tick **"Add Python to PATH"** — otherwise the launcher can't find it.

---

## Quick Start

### 1. Install Ollama
Download and install from [ollama.com/download/windows](https://ollama.com/download/windows), then run:
```
ollama serve
ollama pull qwen2.5-coder:14b
```

### 2. Launch V-Agent

**Terminal (recommended):**
```
bin\V-Agent.exe
```

**GUI:**
```
scripts\start_gui.bat
```

On first launch, the terminal runs a **First Run Wizard** that auto-detects your hardware (CPU, RAM, GPU, VRAM) and recommends the best model for your machine.

---

## Project Structure

```
V-Agent/
├── bin/
│   └── V-Agent.exe          Pre-compiled terminal agent
├── gui/
│   └── GUI.py               Graphical interface (tkinter)
├── src/
│   └── vagent.cpp           C++17 source for V-Agent.exe
├── tools/
│   └── automator.py         Watchdog: auto-corrects scripts dropped in Entrada/
├── scripts/
│   └── start_gui.bat        GUI launcher (auto-detects Python)
├── Entrada/                 [runtime] Drop .bat/.ps1/.cmd here for auto-correction
├── Saida/                   [runtime] Corrected scripts appear here
├── vagent_config.json       [runtime] Auto-generated on first run
├── vagent_session.json      [runtime] Auto-generated session persistence
├── LICENSE                  GPL v3
└── README.md
```

> `Entrada/`, `Saida/`, `vagent_config.json`, and `vagent_session.json` are generated at runtime and excluded from git via `.gitignore`.

---

## Terminal Commands

```
Project
  /index <path>    Index a project folder
  /status          Show project info
  /list [.ext]     List indexed files
  /search <pat>    Search across files (regex)
  /read <file>     Pin file into next AI query
  /explain <file>  Explain a file with AI

Git
  /git status      Git status
  /git diff [f]    Diff (optionally for one file)
  /git log [n]     Last n commits
  /git branch      All branches
  /git commit      AI-generated commit message
  /git push        Push
  /git pull        Pull

Session / UX
  /tokens          Context window usage bar
  /model <name>    Switch AI model
  /clear           Clear conversation history
  /undo            Restore last saved file from .bak
  /copy            Copy last AI response to clipboard
  /theme           Toggle VOIDTUNE purple / classic cyan
  /hw              Show detected hardware
  /cls             Clear screen
  /gui             Launch GUI from terminal
  /exit            Exit

Natural language (just type)
  "create a Python script that parses CSV..."
  "edit main.cpp to add error handling"
  "explain utils.py"
  "plan a REST API in C++"
```

---

## Supported Models

| Model | VRAM | RAM | Notes |
|---|---|---|---|
| `qwen2.5-coder:14b` | 8 GB | 16 GB | Best balance (default) |
| `qwen2.5-coder:7b` | 4 GB | 8 GB | Lighter |
| `deepseek-coder-v2:16b` | 9 GB | 16 GB | Smarter |
| `codellama:13b` | 8 GB | 16 GB | Meta |
| `granite-code:8b` | 5 GB | 8 GB | IBM, fast |

The First Run Wizard auto-recommends based on your detected VRAM and RAM.

---

## Automator (tools/automator.py)

A separate watchdog tool. Drop any `.bat`, `.ps1`, or `.cmd` file into `Entrada/` and it automatically sends it to the AI for error correction, saving the result in `Saida/` as `corrigido_<filename>`.

```
python tools\automator.py
```

Reads model from `vagent_config.json` automatically if present.

---

## Build from Source

Requires [MSYS2](https://www.msys2.org/) with UCRT64 and g++ 13+:

```bash
g++ -std=c++17 -O2 -o bin/V-Agent.exe src/vagent.cpp -lcomdlg32 -static
```

---

## License

GNU General Public License v3.0 — see [LICENSE](LICENSE).
