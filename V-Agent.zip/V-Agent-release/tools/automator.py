import os
import time
import json
import requests
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# ── Paths relative to this script's location (portable) ──────────────────────
BASE_DIR      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # tools/ -> repo root
PASTA_ENTRADA = os.path.join(BASE_DIR, "Entrada")
PASTA_SAIDA   = os.path.join(BASE_DIR, "Saida")
URL_API       = "http://localhost:11434/api/generate"

# Load model from vagent_config.json if present, fallback to default
def _load_model():
    config_path = os.path.join(BASE_DIR, "vagent_config.json")
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        return cfg.get("model_last_used") or cfg.get("model") or "qwen2.5-coder:14b"
    except Exception:
        return "qwen2.5-coder:14b"

MODEL_NAME = _load_model()

def ler_ficheiro(caminho):
    try:
        with open(caminho, 'r', encoding='utf-8') as f:
            return f.read(), None
    except Exception as e:
        return None, f"Erro ao ler: {e}"

def chamar_ia(conteudo):
    prompt = f"""
    És um especialista em scripts Windows. Corrige o código abaixo, mantendo a funcionalidade e adicionando tratamento de erros. Responde APENAS com o código completo.
    
    <codigo_original>
    {conteudo}
    </codigo_original>
    """
    payload = {
        "model": MODEL_NAME,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.1, "num_ctx": 32768}
    }
    try:
        print("   > A enviar para a IA...")
        response = requests.post(URL_API, json=payload, timeout=120)
        response.raise_for_status()
        return response.json()["response"], None
    except Exception as e:
        return None, f"Erro na IA: {e}"

def processar_ficheiro(caminho):
    print(f"\n--- Processando: {os.path.basename(caminho)} ---")
    conteudo, erro = ler_ficheiro(caminho)
    if erro:
        print(f"   > {erro}"); return
    corrigido, erro = chamar_ia(conteudo)
    if erro:
        print(f"   > {erro}"); return
    nome_base = os.path.basename(caminho)
    nome_saida = f"corrigido_{nome_base}"
    caminho_saida = os.path.join(PASTA_SAIDA, nome_saida)
    try:
        with open(caminho_saida, 'w', encoding='utf-8') as f:
            f.write(corrigido)
        print(f"   > Salvo em: {caminho_saida}")
    except Exception as e:
        print(f"   > Erro ao salvar: {e}")

class ScriptHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory and event.src_path.endswith(('.bat', '.ps1', '.cmd')):
            time.sleep(1)
            processar_ficheiro(event.src_path)

if __name__ == "__main__":
    os.makedirs(PASTA_ENTRADA, exist_ok=True)
    os.makedirs(PASTA_SAIDA, exist_ok=True)
    print(f"Monitorizador iniciado!")
    print(f"  Entrada : {PASTA_ENTRADA}")
    print(f"  Saida   : {PASTA_SAIDA}")
    print(f"  Modelo  : {MODEL_NAME}")
    event_handler = ScriptHandler()
    observer = Observer()
    observer.schedule(event_handler, PASTA_ENTRADA, recursive=False)
    try:
        observer.start()
        while True: time.sleep(5)
    except KeyboardInterrupt:
        print("\nParado."); observer.stop()
    observer.join()
