/**
 * vagent.cpp — V-Agent v0.4 | Local AI Coding Agent
 *
 * Build: g++ -std=c++17 -O2 -o vagent.exe vagent.cpp -lcomdlg32 -static
 * Requires: Ollama running locally  →  ollama serve
 *           Model pulled            →  ollama pull qwen2.5-coder:14b
 *
 * v0.4 NEW — FIRST RUN WIZARD:
 *  - Hardware auto-detection (CPU, RAM, GPU, VRAM)
 *  - Smart model recommendation based on detected hardware
 *  - Interactive model selection with numbered menu
 *  - Model tier table (5 recommended models by hardware)
 *  - Auto-download of Ollama if not installed
 *  - Config persistence (vagent_config.json)
 *  - Hardware info injected into system prompt
 *  - /hw command to view detected hardware at any time
 *
 * v0.3 features retained:
 *  - VOIDTUNE dark-purple colour theme
 *  - Git integration (/git status|diff|log|branch|commit|push|pull)
 *  - Session persistence (vagent_session.json)
 *  - /undo, /copy, /theme, /tokens with progress bar
 *  - Coloured diff, streaming print, braille spinner
 *
 * Fixes over original v0.4:
 *  - Added #include <cstdint> for uint64_t
 *  - UI:: namespace prefix added everywhere it was missing (GitManager, VAgentCore)
 *  - Intent detection: initializer_list<string> instead of const char* arrays
 *  - handleEdit: double-askUser bug fixed (asked twice for same confirm)
 *  - VRAM registry read: QWORD (8 bytes) read correctly via ULONGLONG instead of DWORD
 *  - ping(): now verifies response body contains "models", not just curl exit code
 *  - saveConfig/loadConfig: whitespace around ":" in JSON keys made consistent
 */

#include <iostream>
#include <string>
#include <vector>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <regex>
#include <map>
#include <set>
#include <algorithm>
#include <thread>
#include <chrono>
#include <cstdlib>
#include <cstdint>
#include <iomanip>
#include <atomic>
#include <windows.h>
#include <commdlg.h>

namespace fs = std::filesystem;
using namespace std;

// ── Version ───────────────────────────────────────────────────────────────────
static const string VERSION = "0.4.0";

// ── Hardware Info ─────────────────────────────────────────────────────────────
struct HardwareInfo {
    string   cpu;
    int      cores    = 0;
    uint64_t ramGB    = 0;
    uint64_t vramGB   = 0;
    string   gpu;
    bool     detected = false;
};

static HardwareInfo detectHardware() {
    HardwareInfo hw;

    // ── RAM ─────────────────────────────────────────────────────────────────
    MEMORYSTATUSEX mem{};
    mem.dwLength = sizeof(mem);
    if (GlobalMemoryStatusEx(&mem))
        hw.ramGB = mem.ullTotalPhys / (1024ULL * 1024 * 1024);

    // ── CPU name ─────────────────────────────────────────────────────────────
    HKEY hk;
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",
        0, KEY_READ, &hk) == ERROR_SUCCESS) {
        char buf[256] = {};
        DWORD sz = sizeof(buf);
        if (RegQueryValueExA(hk, "ProcessorNameString", nullptr, nullptr,
                             (LPBYTE)buf, &sz) == ERROR_SUCCESS) {
            hw.cpu = buf;
            while (!hw.cpu.empty() && hw.cpu.back() == ' ') hw.cpu.pop_back();
        }
        RegCloseKey(hk);
    }

    // ── CPU core count ────────────────────────────────────────────────────────
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    hw.cores = (int)si.dwNumberOfProcessors;

    // ── GPU + VRAM ────────────────────────────────────────────────────────────
    for (int i = 0; i < 10; ++i) {
        string idx  = to_string(i);
        string path = "SYSTEM\\CurrentControlSet\\Control\\Class\\"
                      "{4d36e968-e325-11ce-bfc1-08002be10318}\\"
                    + string(4 - idx.size(), '0') + idx;

        HKEY hkGpu;
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, path.c_str(),
                          0, KEY_READ, &hkGpu) != ERROR_SUCCESS) continue;

        char gpuName[256] = {};
        DWORD gpuSz = sizeof(gpuName);
        if (RegQueryValueExA(hkGpu, "DriverDesc", nullptr, nullptr,
                             (LPBYTE)gpuName, &gpuSz) == ERROR_SUCCESS)
            hw.gpu = gpuName;

        // VRAM — HardwareInformation.qwMemorySize is a QWORD (8 bytes)
        ULONGLONG vramBytes = 0;
        DWORD     vramSz    = sizeof(vramBytes);
        if (RegQueryValueExA(hkGpu, "HardwareInformation.qwMemorySize",
                             nullptr, nullptr,
                             (LPBYTE)&vramBytes, &vramSz) == ERROR_SUCCESS) {
            hw.vramGB = vramBytes / (1024ULL * 1024 * 1024);
        } else {
            // Fallback: older drivers store MB in DedicatedVideoMemory
            DWORD dedicated = 0;
            DWORD dedSz     = sizeof(dedicated);
            if (RegQueryValueExA(hkGpu, "HardwareInformation.MemorySize",
                                 nullptr, nullptr,
                                 (LPBYTE)&dedicated, &dedSz) == ERROR_SUCCESS)
                hw.vramGB = dedicated / (1024ULL * 1024 * 1024);
        }

        RegCloseKey(hkGpu);
        if (!hw.gpu.empty()) break;
    }

    hw.detected = true;
    return hw;
}

// ── Model recommendations ─────────────────────────────────────────────────────
struct ModelOption {
    string name, vramLabel, ramLabel, note;
};

static vector<ModelOption> getModelOptions() {
    return {
        {"qwen2.5-coder:14b",     "8GB",  "16GB", "Best balance"},
        {"qwen2.5-coder:7b",      "4GB",  "8GB",  "Lighter"},
        {"deepseek-coder-v2:16b", "9GB",  "16GB", "Smarter"},
        {"codellama:13b",         "8GB",  "16GB", "Meta"},
        {"granite-code:8b",       "5GB",  "8GB",  "IBM, fast"},
    };
}

static string recommendModel(const HardwareInfo& hw) {
    if (hw.vramGB >= 8 && hw.ramGB >= 16) return "qwen2.5-coder:14b";
    if (hw.vramGB >= 4 && hw.ramGB >= 8)  return "qwen2.5-coder:7b";
    return "granite-code:8b";
}

// ── Config persistence ────────────────────────────────────────────────────────
struct VAgentConfig {
    string       model;
    bool         firstRun      = true;
    HardwareInfo hw;
    string       modelLastUsed;
};
static VAgentConfig g_config;
static const string CONFIG_FILE = "vagent_config.json";

static void saveConfig() {
    ofstream f(CONFIG_FILE);
    if (!f) return;
    auto esc = [](const string& s) {
        string o;
        for (char c : s) {
            if (c == '"')  o += "\\\"";
            else if (c == '\\') o += "\\\\";
            else o += c;
        }
        return o;
    };
    f << "{\n"
      << "  \"model\": \""           << esc(g_config.model)          << "\",\n"
      << "  \"first_run\": "         << (g_config.firstRun ? "true" : "false") << ",\n"
      << "  \"hardware\": {\n"
      << "    \"cpu\": \""           << esc(g_config.hw.cpu)          << "\",\n"
      << "    \"cores\": "           << g_config.hw.cores             << ",\n"
      << "    \"ram_gb\": "          << g_config.hw.ramGB             << ",\n"
      << "    \"vram_gb\": "         << g_config.hw.vramGB            << ",\n"
      << "    \"gpu\": \""           << esc(g_config.hw.gpu)          << "\"\n"
      << "  },\n"
      << "  \"model_last_used\": \"" << esc(g_config.modelLastUsed)   << "\"\n"
      << "}\n";
}

static void loadConfig() {
    ifstream f(CONFIG_FILE);
    if (!f) return;
    string json((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());

    // Simple key-value string extractor (no external JSON lib)
    auto jg = [&](const string& k) -> string {
        // Try both "key": "val" and "key":"val"
        for (const string& needle : { "\"" + k + "\": \"", "\"" + k + "\":\"" }) {
            size_t p = json.find(needle);
            if (p == string::npos) continue;
            p += needle.size();
            string v;
            for (size_t i = p; i < json.size() && json[i] != '"'; ++i) {
                if (json[i] == '\\' && i+1 < json.size()) { v += json[++i]; }
                else v += json[i];
            }
            return v;
        }
        return "";
    };
    auto jgn = [&](const string& k) -> int64_t {
        for (const string& needle : { "\"" + k + "\": ", "\"" + k + "\":" }) {
            size_t p = json.find(needle);
            if (p == string::npos) continue;
            p += needle.size();
            string n;
            while (p < json.size() && (isdigit((unsigned char)json[p]) || json[p] == '-'))
                n += json[p++];
            if (!n.empty()) try { return stoll(n); } catch (...) {}
        }
        return 0;
    };

    string m = jg("model");
    if (!m.empty()) g_config.model = m;

    g_config.firstRun = (json.find("\"first_run\": false") == string::npos &&
                         json.find("\"first_run\":false")  == string::npos);

    string cpu = jg("cpu");
    if (!cpu.empty()) g_config.hw.cpu = cpu;
    g_config.hw.cores   = (int)jgn("cores");
    g_config.hw.ramGB   = (uint64_t)jgn("ram_gb");
    g_config.hw.vramGB  = (uint64_t)jgn("vram_gb");
    string gpu = jg("gpu");
    if (!gpu.empty()) g_config.hw.gpu = gpu;
    g_config.hw.detected = !cpu.empty();

    string mlu = jg("model_last_used");
    if (!mlu.empty()) g_config.modelLastUsed = mlu;
}

// ── Runtime config ────────────────────────────────────────────────────────────
struct Config {
    string model        = "qwen2.5-coder:14b";
    string ollamaBase   = "http://localhost:11434";
    int    maxHistory   = 30;
    int    maxCtxChars  = 32000;
    int    numCtx       = 32768;
    float  temperature  = 0.15f;
    bool   purpleTheme  = true;
    string sessionFile  = "vagent_session.json";
};
static Config cfg;

// ── Colour palette ────────────────────────────────────────────────────────────
namespace UI {
    const string P_PRI = "\033[38;5;135m";
    const string P_SEC = "\033[38;5;99m";
    const string P_ACC = "\033[38;5;219m";
    const string P_DIM = "\033[38;5;61m";
    const string C_PRI = "\033[36m";
    const string C_SEC = "\033[34m";
    const string C_ACC = "\033[35m";
    const string C_DIM = "\033[2;36m";
    const string RST   = "\033[0m";
    const string BLD   = "\033[1m";
    const string DIM   = "\033[2m";
    const string RED   = "\033[38;5;203m";
    const string GRN   = "\033[38;5;114m";
    const string YEL   = "\033[38;5;221m";
    const string WHT   = "\033[97m";

    inline string pri() { return cfg.purpleTheme ? P_PRI : C_PRI; }
    inline string sec() { return cfg.purpleTheme ? P_SEC : C_SEC; }
    inline string acc() { return cfg.purpleTheme ? P_ACC : C_ACC; }
    inline string dim() { return cfg.purpleTheme ? P_DIM : C_DIM; }

    void clear() { system("cls"); }

    void showSpinner(const string& msg, atomic<bool>& done) {
        const vector<string> frames = {"⣾","⣽","⣻","⢿","⡿","⣟","⣯","⣷"};
        int i = 0;
        while (!done.load(memory_order_relaxed)) {
            cout << "\r  " << pri() << BLD << frames[i % 8] << RST
                 << " " << dim() << msg << RST << flush;
            this_thread::sleep_for(chrono::milliseconds(70));
            ++i;
        }
        cout << "\r" << string(msg.size() + 10, ' ') << "\r" << flush;
    }

    void box(const string& title, int width = 54) {
        int pad = width - 4 - (int)title.size();
        if (pad < 0) pad = 0;
        string h = string(width - 2, '-');
        cout << pri() << BLD
             << "+" << h << "+\n"
             << "|  " << acc() << title << pri() << string(pad, ' ') << "  |\n"
             << "+" << h << "+\n" << RST;
    }

    void line(char c = '-', int w = 56) { cout << dim() << string(w, c) << RST << "\n"; }
    void ok  (const string& s) { cout << GRN  << "  ✓  " << RST << s << "\n"; }
    void err (const string& s) { cout << RED  << "  ✗  " << RST << s << "\n"; }
    void warn(const string& s) { cout << YEL  << "  ⚠  " << RST << s << "\n"; }
    void info(const string& s) { cout << dim()<< "  ·  " << RST << s << "\n"; }

    void streamPrint(const string& text, int delayMs = 6) {
        bool inCode = false;
        for (size_t i = 0; i < text.size(); ++i) {
            if (i + 2 < text.size() &&
                text[i]=='`' && text[i+1]=='`' && text[i+2]=='`') {
                inCode = !inCode;
                cout << (inCode ? sec() + BLD : RST) << "```" << flush;
                i += 2; continue;
            }
            cout << text[i] << flush;
            if (text[i] == ' ' || text[i] == '\n')
                this_thread::sleep_for(chrono::milliseconds(delayMs));
        }
        if (inCode) cout << RST;
        cout << "\n";
    }

    void printDiff(const string& original, const string& modified, int maxLines = 40) {
        istringstream ao(original), am(modified);
        vector<string> lo, lm;
        string ln;
        while (getline(ao, ln)) lo.push_back(ln);
        while (getline(am, ln)) lm.push_back(ln);
        size_t maxLen = max(lo.size(), lm.size());
        int shown = 0;
        for (size_t i = 0; i < maxLen && shown < maxLines; ++i) {
            bool hasO = i < lo.size(), hasM = i < lm.size();
            if (hasO && hasM && lo[i] == lm[i]) continue;
            if (hasO) { cout << RED << "  - " << lo[i] << RST << "\n"; ++shown; }
            if (hasM) { cout << GRN << "  + " << lm[i] << RST << "\n"; ++shown; }
        }
        if (shown == 0) info("No differences found.");
        else if ((int)maxLen > shown)
            cout << dim() << "  ... (truncated at " << maxLines << " lines)\n" << RST;
    }

    bool copyToClipboard(const string& text) {
        if (!OpenClipboard(nullptr)) return false;
        EmptyClipboard();
        HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, text.size() + 1);
        if (!hMem) { CloseClipboard(); return false; }
        memcpy(GlobalLock(hMem), text.c_str(), text.size() + 1);
        GlobalUnlock(hMem);
        SetClipboardData(CF_TEXT, hMem);
        CloseClipboard();
        return true;
    }
} // namespace UI

// ── JSON helpers ──────────────────────────────────────────────────────────────
static string jsonEscape(const string& s) {
    string out; out.reserve(s.size() + 16);
    for (unsigned char c : s) {
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n";  break;
            case '\r': out += "\\r";  break;
            case '\t': out += "\\t";  break;
            default:
                if (c < 0x20) { char b[8]; snprintf(b, 8, "\\u%04x", c); out += b; }
                else out += static_cast<char>(c);
        }
    }
    return out;
}

static string jsonUnescape(const string& s) {
    string out; bool esc = false;
    for (size_t i = 0; i < s.size(); ++i) {
        if (esc) {
            switch (s[i]) {
                case 'n': out += '\n'; break;
                case 'r': out += '\r'; break;
                case 't': out += '\t'; break;
                case '"': out += '"';  break;
                case '\\':out += '\\'; break;
                default:  out += s[i]; break;
            }
            esc = false;
        } else if (s[i] == '\\') esc = true;
        else out += s[i];
    }
    return out;
}

static string jsonGet(const string& json, const string& key) {
    // Accept both "key":"val" and "key": "val"
    string val;
    for (const string& needle : { "\"" + key + "\":\"", "\"" + key + "\": \"" }) {
        size_t pos = json.find(needle);
        if (pos == string::npos) continue;
        pos += needle.size();
        bool esc = false;
        for (size_t i = pos; i < json.size(); ++i) {
            if (esc) { val += '\\'; val += json[i]; esc = false; }
            else if (json[i] == '\\') esc = true;
            else if (json[i] == '"') break;
            else val += json[i];
        }
        return jsonUnescape(val);
    }
    return "";
}

// ── AI client ─────────────────────────────────────────────────────────────────
static string buildChatPayload(const string& sysPr,
                                const vector<pair<string,string>>& hist,
                                const string& userMsg) {
    string msgs;
    auto append = [&](const string& r, const string& c) {
        if (!msgs.empty()) msgs += ",";
        msgs += "{\"role\":\"" + r + "\",\"content\":\"" + jsonEscape(c) + "\"}";
    };
    if (!sysPr.empty()) append("system", sysPr);
    for (const auto& [r, m] : hist) append(r, m);
    append("user", userMsg);
    return "{\"model\":\"" + cfg.model + "\",\"stream\":false,"
           "\"options\":{\"temperature\":" + to_string(cfg.temperature)
         + ",\"num_ctx\":" + to_string(cfg.numCtx) + "},"
           "\"messages\":[" + msgs + "]}";
}

static string parseChatResponse(const string& json) {
    string v = jsonGet(json, "content");
    if (!v.empty()) return v;
    v = jsonGet(json, "response");
    if (!v.empty()) return v;
    v = jsonGet(json, "error");
    return v.empty() ? "[X] No response field" : "[X] Ollama: " + v;
}

class AIClient {
    static string tmpIn()  { return fs::temp_directory_path().string() + "\\vagent_req.json"; }
    static string tmpOut() { return fs::temp_directory_path().string() + "\\vagent_res.json"; }
public:
    static string query(const string& sysPr,
                        const vector<pair<string,string>>& hist,
                        const string& userMsg) {
        string payload = buildChatPayload(sysPr, hist, userMsg);
        { ofstream f(tmpIn()); if (!f) return "[X] Cannot write temp"; f << payload; }
        string cmd = "curl -s --connect-timeout 10 --max-time 180 "
                     "-X POST \"" + cfg.ollamaBase + "/api/chat\""
                     " -H \"Content-Type: application/json\""
                     " --data @\"" + tmpIn() + "\""
                     " -o \"" + tmpOut() + "\" 2>nul";
        if (system(cmd.c_str()) != 0) return "[X] curl failed — is Ollama running?";
        ifstream f(tmpOut());
        if (!f) return "[X] Cannot read response";
        string json((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());
        return json.empty() ? "[X] Empty response" : parseChatResponse(json);
    }

    // ping: hits /api/tags and verifies the body contains "models"
    static bool ping() {
        string tmp = fs::temp_directory_path().string() + "\\vagent_ping.json";
        string cmd = "curl -s --connect-timeout 5 \""
                   + cfg.ollamaBase + "/api/tags\" -o \"" + tmp + "\" 2>nul";
        if (system(cmd.c_str()) != 0) return false;
        ifstream f(tmp);
        if (!f) return false;
        string body((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());
        return body.find("\"models\"") != string::npos;
    }

    static bool modelAvailable(const string& model) {
        string tmp = fs::temp_directory_path().string() + "\\vagent_tags.json";
        string cmd = "curl -s --connect-timeout 5 \""
                   + cfg.ollamaBase + "/api/tags\" -o \"" + tmp + "\" 2>nul";
        if (system(cmd.c_str()) != 0) return false;
        ifstream f(tmp);
        if (!f) return false;
        string b((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());
        return b.find(model) != string::npos;
    }

    static bool pullModel(const string& model) {
        cout << "\n" << UI::YEL << "  Pulling " << model << "...\n" << UI::RST;
        return system(("ollama pull " + model).c_str()) == 0;
    }
};

// ── First Run Wizard ──────────────────────────────────────────────────────────
class FirstRunWizard {
    HardwareInfo hw;
    string       selectedModel;
public:
    bool run() {
        hw = detectHardware();
        UI::clear();
        UI::box("V-AGENT FIRST RUN WIZARD", 64);
        cout << "\n";

        // Step 1: Ollama check
        UI::info("Checking Ollama...\n");
        if (!AIClient::ping()) {
            cout << UI::RED << UI::BLD
                 << "  ┌──────────────────────────────────────────────┐\n"
                 << "  │  Ollama not found!                           │\n"
                 << "  │  V-Agent needs Ollama for local AI.          │\n"
                 << "  └──────────────────────────────────────────────┘\n"
                 << UI::RST;
            cout << UI::YEL << "\n  ? Download & install Ollama? (y/n): " << UI::RST;
            string ans; getline(cin, ans);
            if (ans == "y" || ans == "Y") {
                UI::info("Opening https://ollama.com/download/windows ...");
                system("start https://ollama.com/download/windows");
                UI::info("After installation, restart V-Agent.");
            }
            return false;
        }
        UI::ok("Ollama detected!\n");

        // Step 2: Hardware display
        string rec = recommendModel(hw);
        cout << UI::dim()
             << "  ┌──────────────────────────────────────────────┐\n"
             << "  │  Hardware detected:                          │\n"
             << "  │  CPU  : " << setw(38) << left
                               << (hw.cpu.empty() ? "Unknown" : hw.cpu) << "│\n"
             << "  │  Cores: " << setw(38) << left << to_string(hw.cores)      << "│\n"
             << "  │  RAM  : " << setw(38) << left << (to_string(hw.ramGB)  + " GB") << "│\n"
             << "  │  GPU  : " << setw(38) << left
                               << (hw.gpu.empty() ? "Unknown" : hw.gpu) << "│\n"
             << "  │  VRAM : " << setw(38) << left << (to_string(hw.vramGB) + " GB") << "│\n"
             << "  └──────────────────────────────────────────────┘\n"
             << UI::RST << "\n";

        // Step 3: Model selection
        cout << UI::acc() << UI::BLD << "  Select an AI model:\n\n" << UI::RST;
        auto opts = getModelOptions();
        int recIdx = 0;
        for (int i = 0; i < (int)opts.size(); ++i)
            if (opts[i].name == rec) recIdx = i;

        for (int i = 0; i < (int)opts.size(); ++i) {
            bool isRec = (i == recIdx);
            cout << "      [" << (i+1) << "] "
                 << (isRec ? UI::GRN + string("★ ") : string("  "))
                 << UI::WHT << setw(26) << left << opts[i].name
                 << UI::dim() << setw(10) << left << opts[i].vramLabel
                 << setw(10) << left << opts[i].ramLabel
                 << (isRec ? UI::GRN : UI::dim()) << opts[i].note
                 << UI::RST << "\n";
        }
        cout << "      [6]   " << UI::dim() << "Custom (enter name)\n" << UI::RST << "\n";
        cout << UI::YEL << "      ? Your choice (1-6): " << UI::RST;
        string choice; getline(cin, choice);

        if (choice == "6") {
            cout << UI::YEL << "      ? Model name: " << UI::RST;
            getline(cin, selectedModel);
        } else {
            try {
                int idx = stoi(choice) - 1;
                selectedModel = (idx >= 0 && idx < (int)opts.size()) ? opts[idx].name : rec;
            } catch (...) { selectedModel = rec; }
        }

        // Step 4: Pull if needed
        cout << "\n";
        if (!AIClient::modelAvailable(selectedModel)) {
            if (!AIClient::pullModel(selectedModel)) {
                UI::err("Failed to pull " + selectedModel);
                return false;
            }
            UI::ok("Model ready!");
        } else {
            UI::ok("Model already available.");
        }

        // Step 5: Save config
        cout << UI::YEL << "\n  ? Set as default? (y/n): " << UI::RST;
        string def; getline(cin, def);
        if (def == "y" || def == "Y") {
            g_config.model         = selectedModel;
            g_config.modelLastUsed = selectedModel;
            g_config.hw            = hw;
            g_config.firstRun      = false;
            cfg.model              = selectedModel;
            saveConfig();
            UI::ok(selectedModel + " saved as default.\n");
        }

        UI::info("Starting V-Agent...\n");
        return true;
    }

    const HardwareInfo& getHardware() const { return hw; }
    const string& getModel()          const { return selectedModel; }
};

// ── Git manager ───────────────────────────────────────────────────────────────
class GitManager {
    string repoRoot;

    static string run(const string& args) {
        string tmp = fs::temp_directory_path().string() + "\\vagent_git.txt";
        system(("git " + args + " > \"" + tmp + "\" 2>&1").c_str());
        ifstream f(tmp);
        return f ? string((istreambuf_iterator<char>(f)), istreambuf_iterator<char>()) : "";
    }

public:
    void detect(const string& path) {
        repoRoot.clear();
        fs::path p(path);
        while (!p.empty()) {
            if (fs::exists(p / ".git")) { repoRoot = p.string(); return; }
            fs::path par = p.parent_path();
            if (par == p) break;
            p = par;
        }
    }

    bool          isRepo()        const { return !repoRoot.empty(); }
    const string& root()          const { return repoRoot; }

    string currentBranch() const {
        if (!isRepo()) return "";
        string b = run("branch --show-current");
        if (!b.empty() && b.back() == '\n') b.pop_back();
        return b;
    }

    string lastCommit() const {
        if (!isRepo()) return "";
        return run("log -1 --pretty=format:\"%h %s\"");
    }

    void status() const {
        if (!isRepo()) { UI::err("Not a git repository."); return; }
        cout << UI::pri() << UI::BLD
             << "\n  ── Git Status ──────────────────────────────\n" << UI::RST
             << "  " << UI::dim() << "Branch  " << UI::RST
             << UI::acc() << currentBranch() << UI::RST << "\n"
             << "  " << UI::dim() << "Commit  " << UI::RST
             << lastCommit() << "\n\n";
        string s = run("status --short");
        if (s.empty()) { UI::ok("Working tree clean."); return; }
        istringstream ss(s); string ln;
        while (getline(ss, ln)) {
            if (ln.empty()) continue;
            char st = ln[0];
            string col = (st=='M') ? UI::YEL :
                         (st=='A') ? UI::GRN :
                         (st=='D') ? UI::RED : UI::WHT;
            cout << "  " << col << ln << UI::RST << "\n";
        }
        cout << "\n";
    }

    void diff(const string& file = "") const {
        if (!isRepo()) { UI::err("Not a git repository."); return; }
        string d = run("diff --color=never " + (file.empty() ? "" : "-- \"" + file + "\""));
        if (d.empty()) { UI::info("No unstaged changes."); return; }
        cout << UI::pri() << UI::BLD
             << "\n  ── Diff ────────────────────────────────────\n" << UI::RST;
        istringstream ss(d); string ln;
        while (getline(ss, ln)) {
            if (ln.empty()) { cout << "\n"; continue; }
            bool isAdd = ln[0]=='+' && (ln.size()<3 || ln[1]!='+' || ln[2]!='+');
            bool isDel = ln[0]=='-' && (ln.size()<3 || ln[1]!='-' || ln[2]!='-');
            bool isHdr = ln[0]=='@';
            cout << (isAdd ? UI::GRN : isDel ? UI::RED : isHdr ? UI::acc() : UI::dim())
                 << "  " << ln << UI::RST << "\n";
        }
        cout << "\n";
    }

    void log(int n = 10) const {
        if (!isRepo()) { UI::err("Not a git repository."); return; }
        string out = run("log --oneline -" + to_string(n));
        cout << UI::pri() << UI::BLD
             << "\n  ── Git Log (last " << n << ") ────────────────────\n" << UI::RST;
        istringstream ss(out); string ln;
        while (getline(ss, ln)) {
            if (ln.empty()) continue;
            size_t sp = ln.find(' ');
            if (sp != string::npos)
                cout << "  " << UI::acc() << ln.substr(0,sp) << UI::RST
                     << " " << UI::dim()  << ln.substr(sp)   << UI::RST << "\n";
            else cout << "  " << ln << "\n";
        }
        cout << "\n";
    }

    void branch() const {
        if (!isRepo()) { UI::err("Not a git repository."); return; }
        string out = run("branch -a");
        cout << UI::pri() << UI::BLD
             << "\n  ── Branches ────────────────────────────────\n" << UI::RST;
        istringstream ss(out); string ln;
        while (getline(ss, ln)) {
            if (ln.empty()) continue;
            bool cur = ln.find('*') != string::npos;
            cout << (cur ? UI::GRN + UI::BLD : UI::dim())
                 << "  " << ln << UI::RST << "\n";
        }
        cout << "\n";
    }

    void aiCommit(const vector<pair<string,string>>& hist) {
        if (!isRepo()) { UI::err("Not a git repository."); return; }
        string staged = run("diff --cached --stat");
        if (staged.empty()) { UI::warn("Nothing staged. Run git add first."); return; }
        string diff = run("diff --cached");
        if (diff.size() > 6000) diff = diff.substr(0, 6000) + "\n... [truncated]";

        string sysPr = "You are a git commit message generator. "
                       "Output ONLY the commit message, nothing else. "
                       "Format: <type>(<scope>): <description>  (max 72 chars).";
        cout << "\n";
        atomic<bool> done(false);
        thread sp([&]{ UI::showSpinner("Generating commit message...", done); });
        string msg = AIClient::query(sysPr, hist, "Generate commit message:\n\n" + diff);
        done = true; sp.join();

        while (!msg.empty() && (msg.front()=='"' || msg.front()=='\n')) msg = msg.substr(1);
        while (!msg.empty() && (msg.back()=='"'  || msg.back()=='\n'))  msg.pop_back();

        cout << "\n  " << UI::acc() << UI::BLD << "Proposed:" << UI::RST
             << "\n  " << UI::WHT << msg << UI::RST << "\n\n";

        cout << UI::YEL << "  ? Use this message? (y/edit/n): " << UI::RST;
        string ans; getline(cin, ans);
        if (ans == "n" || ans == "N") { UI::info("Commit cancelled."); return; }
        if (ans == "edit" || ans == "e") {
            cout << UI::YEL << "  ? Edit: " << UI::RST;
            getline(cin, msg);
        }
        cout << "\n" << UI::GRN << run("commit -m \"" + msg + "\"") << UI::RST << "\n";
    }

    void push() const {
        if (!isRepo()) { UI::err("Not a git repository."); return; }
        string out = run("push");
        bool ok = out.find("error") == string::npos;
        cout << (ok ? UI::GRN : UI::RED) << out << UI::RST << "\n";
    }

    void pull() const {
        if (!isRepo()) { UI::err("Not a git repository."); return; }
        string out = run("pull");
        bool ok = out.find("error") == string::npos;
        cout << (ok ? UI::GRN : UI::RED) << out << UI::RST << "\n";
    }
};

// ── Session manager ───────────────────────────────────────────────────────────
class SessionManager {
public:
    static void save(const string& model,
                     const string& projectRoot,
                     const vector<pair<string,string>>& history,
                     const vector<pair<string,string>>& files) {
        ofstream f(cfg.sessionFile);
        if (!f) return;
        f << "{\n  \"model\": \""        << jsonEscape(model)       << "\",\n"
          << "  \"project_root\": \""    << jsonEscape(projectRoot) << "\",\n"
          << "  \"history\": [\n";
        for (size_t i = 0; i < history.size(); ++i) {
            f << "    {\"role\":\""    << jsonEscape(history[i].first)
              << "\",\"content\":\"" << jsonEscape(history[i].second) << "\"}";
            if (i+1 < history.size()) f << ",";
            f << "\n";
        }
        f << "  ],\n  \"files\": [\n";
        for (size_t i = 0; i < files.size(); ++i) {
            f << "    \"" << jsonEscape(files[i].first) << "\"";
            if (i+1 < files.size()) f << ",";
            f << "\n";
        }
        f << "  ]\n}\n";
    }

    static bool exists() { return fs::exists(cfg.sessionFile); }

    struct SessionData {
        string model, projectRoot;
        vector<pair<string,string>> history;
        vector<string> filePaths;
    };

    static SessionData load() {
        SessionData data;
        ifstream f(cfg.sessionFile);
        if (!f) return data;
        string json((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());

        data.model       = jsonGet(json, "model");
        data.projectRoot = jsonGet(json, "project_root");

        size_t hp = json.find("\"history\"");
        if (hp != string::npos) {
            size_t as = json.find('[', hp), ae = json.find(']', as);
            if (as != string::npos && ae != string::npos) {
                string arr = json.substr(as, ae - as);
                size_t pos = 0;
                while ((pos = arr.find("\"role\"", pos)) != string::npos) {
                    string role    = jsonGet(arr.substr(pos), "role");
                    string content = jsonGet(arr.substr(pos), "content");
                    if (!role.empty() && !content.empty())
                        data.history.push_back({role, content});
                    pos += 6;
                }
            }
        }

        size_t fp = json.find("\"files\"");
        if (fp != string::npos) {
            size_t as = json.find('[', fp), ae = json.find(']', as);
            if (as != string::npos && ae != string::npos) {
                string arr = json.substr(as+1, ae-as-1);
                size_t pos = 0;
                while ((pos = arr.find('"', pos)) != string::npos) {
                    size_t end = arr.find('"', pos+1);
                    if (end == string::npos) break;
                    string path = arr.substr(pos+1, end-pos-1);
                    if (!path.empty()) data.filePaths.push_back(jsonUnescape(path));
                    pos = end + 1;
                }
            }
        }
        return data;
    }
};

// ── Project manager ───────────────────────────────────────────────────────────
struct Project {
    string root, name;
    vector<pair<string,string>> files;
    int total_files = 0, total_lines = 0;
};

class ProjectManager {
    Project proj;

    static const vector<string>& codeExts() {
        static const vector<string> e = {
            ".cpp",".c",".h",".hpp",".cc",".cxx",
            ".py",".js",".ts",".mjs",".cjs",
            ".rs",".go",".zig",".ps1",".psm1",".bat",".cmd",".sh",
            ".java",".cs",".kt",".swift",
            ".txt",".md",".html",".css",".json",".yaml",".yml",".toml",
            ".xml",".csv"
        };
        return e;
    }

    static bool skipDir(const string& n) {
        static const set<string> s = {
            ".git",".svn","node_modules","__pycache__",
            ".vs","x64","Debug","Release","build","dist","out",
            ".cache",".idea",".vscode","target","bin","obj"
        };
        return s.count(n) > 0;
    }

public:
    const Project& get() const { return proj; }

    void index(const string& path) {
        proj = {}; proj.root = path;
        proj.name = fs::path(path).filename().string();
        if (proj.name.empty()) proj.name = path;
        cout << UI::pri() << "\n  [>] Scanning: " << path << UI::RST << "\n";
        try {
            fs::recursive_directory_iterator it(path,
                fs::directory_options::skip_permission_denied), end;
            for (; it != end; ++it) {
                if (it->is_directory()) {
                    if (skipDir(it->path().filename().string()))
                        it.disable_recursion_pending();
                    continue;
                }
                if (!it->is_regular_file()) continue;
                string ext = it->path().extension().string();
                if (find(codeExts().begin(), codeExts().end(), ext) == codeExts().end()) continue;
                if (fs::file_size(it->path()) > 1024*1024) continue;
                proj.total_files++;
                ifstream f(it->path(), ios::binary);
                if (f) {
                    string c((istreambuf_iterator<char>(f)), {});
                    proj.total_lines += (int)count(c.begin(), c.end(), '\n') + 1;
                }
                proj.files.push_back({it->path().string(), ext});
            }
        } catch (const fs::filesystem_error& e) {
            UI::warn("Scan: " + string(e.what()));
        }
        UI::ok(to_string(proj.total_files) + " files  ("
             + to_string(proj.total_lines) + " lines)");
    }

    void restoreFiles(const string& root, const vector<string>& paths) {
        proj = {}; proj.root = root;
        proj.name = fs::path(root).filename().string();
        for (const auto& p : paths) {
            if (!fs::exists(p)) continue;
            proj.files.push_back({p, fs::path(p).extension().string()});
            proj.total_files++;
        }
        UI::ok("Restored " + to_string(proj.total_files) + " files.");
    }

    string findFile(const string& q) const {
        if (fs::exists(q)) return q;
        string lq = q;
        transform(lq.begin(), lq.end(), lq.begin(), ::tolower);
        for (const auto& [p, e] : proj.files) {
            string lp = p;
            transform(lp.begin(), lp.end(), lp.begin(), ::tolower);
            if (lp.find(lq) != string::npos) return p;
        }
        return "";
    }

    static string readFile(const string& path, size_t maxBytes = 256*1024) {
        ifstream f(path, ios::binary);
        if (!f) return "";
        string c((istreambuf_iterator<char>(f)), {});
        if (c.size() > maxBytes) { c.resize(maxBytes); c += "\n... [truncated]"; }
        return c;
    }

    vector<string> search(const string& pattern, int maxMatches = 50) const {
        vector<string> results;
        regex re;
        try { re = regex(pattern, regex::icase); }
        catch (...) {
            re = regex(regex_replace(pattern,
                regex(R"([.^$*+?()[\]{}\\|])"), "\\$&"), regex::icase);
        }
        for (const auto& [path, ext] : proj.files) {
            ifstream f(path); if (!f) continue;
            string line; int lineNo = 0;
            while (getline(f, line) && (int)results.size() < maxMatches) {
                ++lineNo;
                if (regex_search(line, re)) {
                    size_t s = line.find_first_not_of(" \t");
                    results.push_back(path + ":" + to_string(lineNo) + ":  "
                        + (s != string::npos ? line.substr(s) : line));
                }
            }
            if ((int)results.size() >= maxMatches) break;
        }
        return results;
    }

    void listFiles(const string& filterExt = "") const {
        if (proj.total_files == 0) { UI::err("No project indexed."); return; }
        int shown = 0;
        for (const auto& [p, e] : proj.files) {
            if (!filterExt.empty() && e != filterExt) continue;
            cout << UI::dim() << "  " << p << UI::RST << "\n"; ++shown;
        }
        cout << "\n" << UI::pri() << "  " << shown << " file(s)\n" << UI::RST;
    }

    string context() const {
        if (proj.total_files == 0) return "";
        string ctx = "Project: " + proj.name + "\nRoot: " + proj.root + "\n"
                   + "Files: " + to_string(proj.total_files)
                   + " | Lines: " + to_string(proj.total_lines) + "\n\n";
        for (const auto& [p, e] : proj.files) {
            string entry = "  " + p + "\n";
            if ((int)(ctx.size() + entry.size()) > cfg.maxCtxChars) {
                ctx += "  ...\n"; break;
            }
            ctx += entry;
        }
        return ctx;
    }
};

// ── Conversation history ──────────────────────────────────────────────────────
class ConversationHistory {
    vector<pair<string,string>> turns;
public:
    void addUser     (const string& m) { turns.push_back({"USER",      m}); trim(); }
    void addAssistant(const string& m) { turns.push_back({"ASSISTANT", m}); trim(); }
    void clear()                       { turns.clear(); }
    void restore(const vector<pair<string,string>>& v) { turns = v; }

    const vector<pair<string,string>>& get() const { return turns; }

    string lastAssistant() const {
        for (int i = (int)turns.size()-1; i >= 0; --i)
            if (turns[i].first == "ASSISTANT") return turns[i].second;
        return "";
    }

    int estimatedTokens() const {
        int t = 0;
        for (const auto& [r, m] : turns) t += (int)m.size();
        return t / 4;
    }

    int turnCount() const { return (int)turns.size() / 2; }

private:
    void trim() {
        while ((int)turns.size() > cfg.maxHistory * 2)
            turns.erase(turns.begin(), turns.begin() + 2);
    }
};

// ── Intent detection ──────────────────────────────────────────────────────────
enum class Intent { Create, Edit, Explain, Plan, Chat };

static Intent detectIntent(const string& msg) {
    string lm = msg;
    transform(lm.begin(), lm.end(), lm.begin(), ::tolower);
    bool hasFn = regex_search(lm, regex(R"(\S+\.\w{1,6})"));

    // Use vector<string> so .find() works on std::string, not const char*
    if (hasFn) {
        for (const string& v : vector<string>{
            "edita","edit ","modifica","altera","muda ","corrige",
            "adiciona","refactor","remove ","apaga ","fix ","update ",
            "change ","rewrite","reescreve"})
            if (lm.find(v) != string::npos) return Intent::Edit;
    }
    for (const string& v : vector<string>{
        "explica","explain","analisa","analyse","analyze",
        "o que faz","o que é","what does","what is","descreve"})
        if (lm.find(v) != string::npos) return Intent::Explain;

    for (const string& v : vector<string>{
        "plano","plan ","planeia","roadmap","architecture",
        "arquitetura","como organizar","how to structure","design a"})
        if (lm.find(v) != string::npos) return Intent::Plan;

    for (const string& v : vector<string>{
        "cria ","criar ","make a","make me","create a","create me",
        "faz um","faz uma","gera ","gerar ","write a","escreve ",
        "generate a","build a","new file","novo ficheiro"})
        if (lm.find(v) != string::npos) return Intent::Create;

    return Intent::Chat;
}

// ── Shared helpers ────────────────────────────────────────────────────────────
static string extractCode(const string& r) {
    static const regex fenced(R"(```(?:[a-zA-Z0-9+#\-]*\n)?([\s\S]*?)```)");
    smatch m;
    return regex_search(r, m, fenced) ? m[1].str() : r;
}

static string guessFilename(const string& prompt, const string& code) {
    smatch em;
    if (regex_search(prompt, em,
            regex(R"(\b(\w[\w\-]*)\.(cpp|c|h|hpp|py|js|ts|html|css|md|txt|java|cs|ps1|bat|sh|go|rs)\b)")))
        return em[1].str() + "." + em[2].str();
    string lp = prompt;
    transform(lp.begin(), lp.end(), lp.begin(), ::tolower);
    if (code.find("#include")    != string::npos) return "main.cpp";
    if (code.find("def ")        != string::npos &&
        code.find("import ")     != string::npos) return "script.py";
    if (code.find("<!DOCTYPE")   != string::npos ||
        code.find("<html")       != string::npos) return "index.html";
    if (code.find("console.log") != string::npos) return "script.js";
    if (code.find("import React")!= string::npos) return "App.jsx";
    if (code.find("#Requires")   != string::npos ||
        code.find("Write-Output")!= string::npos) return "script.ps1";
    if (lp.find("readme")   != string::npos) return "README.md";
    if (lp.find(" html")    != string::npos ||
        lp.find("website")  != string::npos) return "index.html";
    if (lp.find(" css")     != string::npos) return "style.css";
    if (lp.find("python")   != string::npos) return "script.py";
    if (lp.find("javascript")!= string::npos ||
        lp.find(" js ")     != string::npos) return "script.js";
    if (lp.find("powershell")!= string::npos) return "script.ps1";
    if (lp.find("bash")     != string::npos ||
        lp.find("shell")    != string::npos) return "script.sh";
    return "output.txt";
}

static string lastSavedPath;

static void saveFile(const string& path, const string& content) {
    if (fs::exists(path)) {
        CopyFileA(path.c_str(), (path + ".bak").c_str(), FALSE);
        UI::info("Backup: " + path + ".bak");
    }
    ofstream out(path);
    if (!out) { UI::err("Cannot write: " + path); return; }
    out << content;
    lastSavedPath = path;
    UI::ok("Saved: " + path);
    UI::line();
}

static void previewContent(const string& content, int maxLines = 15) {
    istringstream ss(content); string ln; int n = 0;
    int total = (int)count(content.begin(), content.end(), '\n');
    while (getline(ss, ln) && n < maxLines) {
        cout << UI::sec() << "  │ " << UI::RST << ln << "\n"; ++n;
    }
    if (n < total)
        cout << UI::dim() << "  │ ... (" << total << " total lines)\n" << UI::RST;
}

// ── Core agent ────────────────────────────────────────────────────────────────
class VAgentCore {
    ProjectManager      pm;
    ConversationHistory hist;
    GitManager          git;
    string              pinnedContent, pinnedPath;
    HardwareInfo        hw;

    string askUser(const string& q) {
        cout << UI::YEL << "  ? " << q << ": " << UI::RST;
        string a; getline(cin, a); return a;
    }

    string chooseSavePath(const string& suggested) {
        OPENFILENAMEA ofn{};
        char szFile[260] = {};
        strncpy(szFile, suggested.c_str(), sizeof(szFile) - 1);
        ofn.lStructSize  = sizeof(ofn);
        ofn.hwndOwner    = GetConsoleWindow();
        ofn.lpstrFile    = szFile;
        ofn.nMaxFile     = sizeof(szFile);
        ofn.lpstrFilter  = "All Files\0*.*\0C/C++\0*.cpp;*.c;*.h\0"
                           "Python\0*.py\0JS/TS\0*.js;*.ts\0"
                           "HTML/CSS\0*.html;*.css\0PS\0*.ps1\0MD\0*.md\0";
        ofn.nFilterIndex = 1;
        ofn.Flags        = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;
        ofn.lpstrTitle   = "Save file as...";
        return GetSaveFileNameA(&ofn) ? string(szFile) : "";
    }

    string buildSysPr(const string& base) {
        string s = base + "\n\nProject context:\n" + pm.context();
        if (git.isRepo())
            s += "\nGit branch: " + git.currentBranch()
               + "\nLast commit: " + git.lastCommit() + "\n";
        if (hw.detected)
            s += "\nHardware: " + hw.cpu + " | " + to_string(hw.ramGB) + "GB RAM | "
               + hw.gpu + " (" + to_string(hw.vramGB) + "GB VRAM)\n";
        if (!pinnedContent.empty()) {
            s += "\nFile in context (" + pinnedPath + "):\n```\n" + pinnedContent + "\n```";
            pinnedContent.clear(); pinnedPath.clear();
        }
        return s;
    }

    string querySpinner(const string& sysPr, const string& userMsg, const string& msg) {
        atomic<bool> done(false);
        thread sp([&]{ UI::showSpinner(msg, done); });
        string r = AIClient::query(sysPr, hist.get(), userMsg);
        done = true; sp.join();
        return r;
    }

    void autosave() {
        SessionManager::save(cfg.model, pm.get().root, hist.get(), pm.get().files);
    }

    void handleCreate(const string& prompt) {
        string lp = prompt;
        transform(lp.begin(), lp.end(), lp.begin(), ::tolower);
        string ft;
        smatch em;
        if (regex_search(prompt, em,
                regex(R"(\b\w+\.(cpp|c|h|py|js|ts|html|css|md|txt|ps1|java|cs|go|rs|sh)\b)")))
            ft = em[1].str();

        if (ft.empty()) {
            for (const auto& [h, e] : vector<pair<string,string>>{
                {"readme","md"},{"html","html"},{"website","html"},{"css","css"},
                {"javascript","js"},{" js ","js"},{"python","py"},{"c++","cpp"},
                {".cpp","cpp"},{"powershell","ps1"},{"bash","sh"},{"typescript","ts"},
                {"java","java"},{"golang","go"},{" go ","go"}})
                if (lp.find(h) != string::npos) { ft = e; break; }
        }

        if (ft.empty()) {
            cout << UI::YEL << "  ? File type (cpp/py/js/html/css/md/ps1/sh): " << UI::RST;
            getline(cin, ft);
            transform(ft.begin(), ft.end(), ft.begin(), ::tolower);
        }

        static const map<string,string> sysByType = {
            {"cpp",  "Expert C++17 developer. Write clean, modern code. Output ONLY one fenced code block."},
            {"c",    "C developer. Write clean C99/C11. Output ONLY one fenced code block."},
            {"py",   "Python developer. Write Python 3 with type hints. Output ONLY one fenced code block."},
            {"js",   "JavaScript developer. Write ES2022+. Output ONLY one fenced code block."},
            {"ts",   "TypeScript developer. Write typed code. Output ONLY one fenced code block."},
            {"html", "Web developer. Write a complete self-contained HTML5 page. Output ONLY one fenced code block."},
            {"css",  "CSS developer. Write modern CSS. Output ONLY one fenced code block."},
            {"md",   "Technical writer. Write a professional Markdown README. Output ONLY one fenced code block."},
            {"ps1",  "PowerShell developer. Write PS 5.1+ with CmdletBinding. Output ONLY one fenced code block."},
            {"sh",   "Bash developer. Write portable bash with set -euo pipefail. Output ONLY one fenced code block."},
            {"go",   "Go developer. Write idiomatic Go. Output ONLY one fenced code block."},
            {"java", "Java developer. Write clean Java 17+. Output ONLY one fenced code block."},
        };
        string base = sysByType.count(ft) ? sysByType.at(ft)
                    : "Output ONLY one fenced code block.";
        string sysPr = buildSysPr("You are V-Agent, expert " + ft + " developer. " + base);

        string resp = querySpinner(sysPr, prompt, "Generating " + ft + "...");
        hist.addUser(prompt); hist.addAssistant(resp);

        string code = extractCode(resp);
        string suggested = guessFilename(prompt, code);

        cout << UI::pri() << UI::BLD << "\n  -- Preview -----------------------------\n" << UI::RST;
        previewContent(code); cout << "\n";

        string savePath = chooseSavePath(suggested);
        if (savePath.empty()) { UI::err("Save cancelled."); return; }
        saveFile(savePath, code);
        autosave();
    }

    void handleEdit(const string& prompt) {
        smatch fm; string fn;
        if (regex_search(prompt, fm, regex(R"((\S+\.\w{1,6}))"))) fn = fm[1].str();
        if (fn.empty()) { UI::err("No filename detected."); return; }

        string filepath = pm.findFile(fn);
        if (filepath.empty()) { UI::err("File not found: " + fn); return; }

        string original = ProjectManager::readFile(filepath);
        if (original.empty()) { UI::err("Cannot read: " + filepath); return; }

        string sysPr = buildSysPr(
            "You are a precise code editor. "
            "Output ONLY the complete modified file in a single fenced code block.");
        string userMsg = "File: " + filepath + "\n\n```\n" + original
                       + "\n```\n\nInstructions: " + prompt;

        string resp = querySpinner(sysPr, userMsg, "Editing " + fn + "...");
        hist.addUser(prompt); hist.addAssistant(resp);

        string modified = extractCode(resp);
        if (modified.size() < 10) { UI::err("Response malformed -- aborting."); return; }

        cout << UI::pri() << UI::BLD << "\n  -- Diff Preview ------------------------\n" << UI::RST;
        UI::printDiff(original, modified); cout << "\n";

        string ans = askUser("Apply changes? (y/n)");
        if (ans == "y" || ans == "Y") {
            saveFile(filepath, modified); autosave();
        } else {
            UI::info("Cancelled.");
        }
    }

    void handleExplain(const string& prompt) {
        smatch fm; string fn;
        if (regex_search(prompt, fm, regex(R"((\S+\.\w{1,6}))"))) fn = fm[1].str();

        string userMsg;
        if (!fn.empty()) {
            string fp = pm.findFile(fn);
            if (fp.empty()) { UI::err("File not found: " + fn); return; }
            string code = ProjectManager::readFile(fp);
            if (code.empty()) { UI::err("Cannot read: " + fp); return; }
            userMsg = "Explain this file (" + fp + "):\n\n```\n" + code + "\n```";
        } else { userMsg = prompt; }

        string sysPr = buildSysPr(
            "You are an expert code reviewer. Explain clearly and concisely.");
        string resp = querySpinner(sysPr, userMsg, "Analysing...");
        hist.addUser(userMsg); hist.addAssistant(resp);
        cout << "\n"; UI::streamPrint("  " + resp); cout << "\n";
        autosave();
    }

    void handlePlan(const string& prompt) {
        string sysPr = buildSysPr(
            "You are a senior software architect. "
            "Produce a clear, numbered, step-by-step implementation plan.");
        string resp = querySpinner(sysPr, prompt, "Planning...");
        hist.addUser(prompt); hist.addAssistant(resp);
        cout << "\n"; UI::streamPrint("  " + resp); cout << "\n";
        autosave();
    }

    void handleChat(const string& message) {
        string sysPr = buildSysPr(
            "You are V-Agent, a local AI coding assistant. "
            "Be direct, concise, conversational -- like a senior colleague. "
            "Format code in fenced blocks.");
        string resp = querySpinner(sysPr, message, "Thinking...");
        hist.addUser(message); hist.addAssistant(resp);
        cout << "\n"; UI::streamPrint("  " + resp); cout << "\n";
        autosave();
    }

public:
    void launchGUI() {
        SessionManager::save(cfg.model, pm.get().root, hist.get(), pm.get().files);
        UI::ok("Launching V-Agent GUI...");
        system("cmd /c \"where pythonw >nul 2>&1 && start /b pythonw ..\\gui\\GUI.py 2>nul || start /b python ..\\gui\\GUI.py 2>nul\"");
        UI::info("GUI launched in separate window.");
    }
 
    void setHardware(const HardwareInfo& hwinfo) { hw = hwinfo; }
    void index(const string& path) { pm.index(path); git.detect(path); autosave(); }

    void status() {
        const auto& p = pm.get();
        cout << UI::pri() << UI::BLD
             << "\n  -- Project ---------------------------------\n" << UI::RST;
        if (p.total_files == 0) { UI::err("No project indexed."); return; }
        cout << "  " << UI::dim() << "Name   " << UI::RST << p.name        << "\n"
             << "  " << UI::dim() << "Path   " << UI::RST << p.root        << "\n"
             << "  " << UI::dim() << "Files  " << UI::RST << p.total_files << "\n"
             << "  " << UI::dim() << "Lines  " << UI::RST << p.total_lines << "\n";
        if (git.isRepo())
            cout << "  " << UI::dim() << "Branch " << UI::RST
                 << UI::acc() << git.currentBranch() << UI::RST << "\n"
                 << "  " << UI::dim() << "Commit " << UI::RST
                 << git.lastCommit() << "\n";
        if (hw.detected)
            cout << "  " << UI::dim() << "HW     " << UI::RST
                 << hw.cpu << " | " << hw.ramGB << "GB RAM | "
                 << hw.gpu << " (" << hw.vramGB << "GB)\n";
        cout << "\n";
    }

    void showHardware() {
        if (!hw.detected) { UI::err("Hardware not detected."); return; }
        UI::box("HARDWARE");
        cout << "\n"
             << "  " << UI::dim() << "CPU  " << UI::RST << hw.cpu << " (" << hw.cores << " cores)\n"
             << "  " << UI::dim() << "RAM  " << UI::RST << hw.ramGB  << " GB\n"
             << "  " << UI::dim() << "GPU  " << UI::RST << hw.gpu   << "\n"
             << "  " << UI::dim() << "VRAM " << UI::RST << hw.vramGB << " GB\n\n";
    }

    void listFiles(const string& ext = "") { pm.listFiles(ext); }

    void searchFiles(const string& q) {
        auto r = pm.search(q);
        if (r.empty()) { UI::info("No matches: " + q); return; }
        cout << UI::pri() << "\n  " << r.size() << " match(es):\n" << UI::RST;
        for (const auto& s : r) cout << UI::dim() << "  " << s << UI::RST << "\n";
        cout << "\n";
    }

    void readFile(const string& q) {
        string fp = pm.findFile(q);
        if (fp.empty()) { UI::err("Not found: " + q); return; }
        pinnedContent = ProjectManager::readFile(fp);
        pinnedPath = fp;
        UI::ok("Pinned: " + fp + " -> next query");
    }

    void showTokens() {
        int est   = hist.estimatedTokens();
        int avail = cfg.numCtx - est;
        int pct   = est * 100 / max(cfg.numCtx, 1);
        UI::box("CONTEXT STATUS");
        cout << "\n"
             << "  " << UI::dim() << "Model  " << UI::RST << cfg.model         << "\n"
             << "  " << UI::dim() << "Window " << UI::RST << cfg.numCtx << " tokens\n"
             << "  " << UI::dim() << "Turns  " << UI::RST << hist.turnCount()
             << " / " << cfg.maxHistory << "\n"
             << "  " << UI::dim() << "Used   " << UI::RST << "~" << est
             << " (" << pct << "%)\n";
        int w = 32, filled = pct * w / 100;
        string col = pct > 80 ? UI::RED : (pct > 50 ? UI::YEL : UI::GRN);
        cout << "  " << col << "[";
        for (int i = 0; i < w; ++i) cout << (i < filled ? "#" : "-");
        cout << "] " << pct << "%" << UI::RST << "\n";
        cout << (avail < 5000 ? UI::YEL : UI::GRN)
             << "  Available: ~" << avail
             << (avail < 5000 ? "  WARNING LOW" : "") << "\n\n" << UI::RST;
    }

    void setModel(const string& model) {
        if (!AIClient::modelAvailable(model)) {
            UI::err("Not available locally: " + model);
            UI::info("Pull: ollama pull " + model);
            return;
        }
        cfg.model = model;
        g_config.modelLastUsed = model;
        UI::ok("Model: " + model);
        autosave(); saveConfig();
    }

    void clearHistory() { hist.clear(); UI::ok("History cleared."); autosave(); }

    void undoLastSave() {
        if (lastSavedPath.empty()) { UI::err("Nothing to undo."); return; }
        string bak = lastSavedPath + ".bak";
        if (!fs::exists(bak)) { UI::err("No backup for: " + lastSavedPath); return; }
        CopyFileA(bak.c_str(), lastSavedPath.c_str(), FALSE);
        UI::ok("Restored: " + lastSavedPath);
        lastSavedPath.clear();
    }

    void copyLastResponse() {
        string last = hist.lastAssistant();
        if (last.empty()) { UI::err("Nothing to copy."); return; }
        UI::copyToClipboard(last) ? UI::ok("Copied to clipboard.") : UI::err("Clipboard failed.");
    }

    void toggleTheme() {
        cfg.purpleTheme = !cfg.purpleTheme;
        UI::ok(string("Theme: ") + (cfg.purpleTheme ? "VOIDTUNE purple" : "Classic cyan"));
    }

    void gitStatus()                    { git.status(); }
    void gitDiff(const string& f = "")  { git.diff(f); }
    void gitLog(int n = 10)             { git.log(n); }
    void gitBranch()                    { git.branch(); }
    void gitCommit()                    { git.aiCommit(hist.get()); autosave(); }
    void gitPush()                      { git.push(); }
    void gitPull()                      { git.pull(); }

    bool loadSession() {
        if (!SessionManager::exists()) return false;
        auto d = SessionManager::load();
        if (d.model.empty() && d.filePaths.empty()) return false;
        if (!d.model.empty())       cfg.model = d.model;
        if (!d.history.empty())     hist.restore(d.history);
        if (!d.projectRoot.empty()) {
            pm.restoreFiles(d.projectRoot, d.filePaths);
            git.detect(d.projectRoot);
        }
        return true;
    }

    void processMessage(const string& msg) {
        switch (detectIntent(msg)) {
            case Intent::Create:  handleCreate(msg);  break;
            case Intent::Edit:    handleEdit(msg);    break;
            case Intent::Explain: handleExplain(msg); break;
            case Intent::Plan:    handlePlan(msg);    break;
            case Intent::Chat:    handleChat(msg);    break;
        }
    }

    void explainFile(const string& q) { handleExplain("explain " + q); }
};

// ── App shell ─────────────────────────────────────────────────────────────────
class VAgentApp {
    VAgentCore core;
    bool       running = true;

    void banner() {
        UI::clear();
        cout << "\033[38;5;93m" << UI::BLD << R"(
  __     __         _               
  \ \   / /        | |              
   \ \_/ /   __ _  | |_    ___  _ __ 
    \   /   / _` | | __|  / _ \| '__|
    | |   | (_| | | |_  |  __/| |   
    |_|    \__,_|  \__|  \___||_|   
                                    
  V-Agent v)" << VERSION << R"( -- Local AI Coding Agent
)" << UI::RST;
        cout << UI::P_DIM
             << "  Model: " << cfg.model
             << "  .  Offline  .  Zero Telemetry\n"
             << "  /help for commands  .  Just talk naturally\n\n" << UI::RST;
        UI::line('-', 64); cout << "\n";
    }

    void help() {
        UI::box("COMMANDS", 60);
        cout << "\n"
             << UI::acc() << "  Project\n" << UI::RST
             << "    /index <path>    /status    /list [.ext]\n"
             << "    /search <pat>    /read <f>  /explain <f>\n\n"
             << UI::acc() << "  Git\n" << UI::RST
             << "    /git status|diff [f]|log [n]|branch|commit|push|pull\n\n"
             << UI::acc() << "  Session / UX\n" << UI::RST
             << "    /tokens   /model <name>   /clear   /undo\n"
             << "    /copy     /theme          /hw      /cls   /gui   /exit\n\n"
             << UI::acc() << "  Natural language\n" << UI::RST
             << "    \"create a Python script that...\"\n"
             << "    \"edit main.cpp to add error handling\"\n"
             << "    \"explain utils.py\"\n"
             << "    \"plan a REST API in C++\"\n\n";
    }

    static bool sw(const string& s, const string& p) { return s.rfind(p, 0) == 0; }
    static int  parseN(const string& s, int def = 10) {
        try { return stoi(s); } catch (...) { return def; }
    }

public:
    void run() {
        SetConsoleOutputCP(CP_UTF8);
        SetConsoleCP(CP_UTF8);

        loadConfig();
        if (!g_config.model.empty()) cfg.model = g_config.model;

        if (g_config.firstRun || !fs::exists(CONFIG_FILE)) {
            FirstRunWizard wizard;
            if (!wizard.run()) {
                cout << UI::RED << "\n  Setup incomplete. Run again after installing Ollama.\n\n" << UI::RST;
                return;
            }
            core.setHardware(wizard.getHardware());
            cfg.model = wizard.getModel();
        } else if (g_config.hw.detected) {
            core.setHardware(g_config.hw);
        }

        banner();

        if (SessionManager::exists()) {
            cout << UI::P_DIM << "  Restore previous session? (y/n): " << UI::RST;
            string ans; getline(cin, ans);
            if (ans == "y" || ans == "Y") {
                if (core.loadSession()) UI::ok("Session restored.");
                else                    UI::warn("Session malformed -- fresh start.");
            }
            cout << "\n";
        }

        cout << UI::YEL << "  Connecting to Ollama..." << UI::RST << flush;
        if (!AIClient::ping()) {
            cout << "\n\n";
            UI::err("Ollama unreachable.");
            UI::info("Start:  ollama serve");
            UI::info("Pull:   ollama pull " + cfg.model);
            cout << "\n"; return;
        }
        cout << UI::GRN << " OK\n" << UI::RST;

        if (!AIClient::modelAvailable(cfg.model))
            UI::warn("Model \"" + cfg.model + "\" not found. Use /model to switch.");

        if (!SessionManager::exists()) core.index(fs::current_path().string());
        cout << "\n";

        string input;
        while (running) {
            cout << UI::P_PRI << UI::BLD << "  vagent" << UI::P_ACC << " > " << UI::RST;
            if (!getline(cin, input)) break;
            if (input.empty()) continue;

            if      (input == "/help")    help();
            else if (input == "/status")  core.status();
            else if (input == "/hw")      core.showHardware();
            else if (input == "/tokens")  core.showTokens();
            else if (input == "/clear")   core.clearHistory();
            else if (input == "/undo")    core.undoLastSave();
            else if (input == "/copy")    core.copyLastResponse();
            else if (input == "/theme")   core.toggleTheme();
            else if (input == "/cls")     { UI::clear(); banner(); }
            else if (input == "/gui") {
                UI::ok("Launching V-Agent GUI...");
                core.launchGUI();
            }
            else if (input == "/exit") {
                cout << UI::P_ACC << "\n  Goodbye. Your code never left this machine.\n\n" << UI::RST;
                running = false;
            }
            else if (sw(input, "/index "))   core.index(input.substr(7));
            else if (sw(input, "/explain ")) core.explainFile(input.substr(9));
            else if (sw(input, "/read "))    core.readFile(input.substr(6));
            else if (sw(input, "/search "))  core.searchFiles(input.substr(8));
            else if (sw(input, "/model "))   core.setModel(input.substr(7));
            else if (sw(input, "/list")) {
                string arg = input.size() > 5 ? input.substr(5) : "";
                if (!arg.empty() && arg[0] == ' ') arg = arg.substr(1);
                core.listFiles(arg);
            }
            else if (input == "/git status")          core.gitStatus();
            else if (input == "/git diff")            core.gitDiff();
            else if (sw(input, "/git diff "))         core.gitDiff(input.substr(10));
            else if (input == "/git log")             core.gitLog();
            else if (sw(input, "/git log "))          core.gitLog(parseN(input.substr(9)));
            else if (input == "/git branch")          core.gitBranch();
            else if (input == "/git commit")          core.gitCommit();
            else if (input == "/git push")            core.gitPush();
            else if (input == "/git pull")            core.gitPull();
            else if (input == "/git") {
                cout << UI::YEL
                     << "\n  Subcommands: status | diff [f] | log [n] | branch | commit | push | pull\n\n"
                     << UI::RST;
            }
            else core.processMessage(input);
        }
    }
};

// ── Entry point ───────────────────────────────────────────────────────────────
int main() {
    // ── Portability: resolve paths relative to the exe location ─────────────
    // exe lives in bin/ — repo root is one level up
    // CWD is set to repo root so all relative paths work from there.
    {
        char exePath[MAX_PATH] = {};
        if (GetModuleFileNameA(nullptr, exePath, MAX_PATH) != 0) {
            fs::path exeDir  = fs::path(exePath).parent_path();
            fs::path repoRoot = exeDir.parent_path(); // bin/ -> repo root
            std::error_code ec;
            fs::current_path(repoRoot, ec); // silently ignore if it fails
        }
    }

    // Launch GUI silently in background
    // Try pythonw first (no console window), fallback to python
    {
        // Build a cmd that tries pythonw, falls back to python, silently
        const char* launchCmd =
            "cmd /c "where pythonw >nul 2>&1 && "
            "start /b pythonw ..\\gui\\GUI.py 2>nul || "
            "start /b python ..\\gui\\GUI.py 2>nul"";
        system(launchCmd);
    }

    // Run the terminal agent
    VAgentApp app;
    app.run();
    return 0;
}