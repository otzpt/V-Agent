#!/usr/bin/env python3
"""
V-Agent Terminal GUI v2.1
Local AI Coding Agent — Graphical Interface
"""

import tkinter as tk
from tkinter import font, scrolledtext
import datetime
import random
import threading
import time
import json
import os
import sys
import requests

class VAgentTerminal:
    def __init__(self, root):
        self.root = root
        self.root.title("V-Agent Terminal")
        self.root.geometry("900x600")
        self.root.configure(bg="#1a1b26")
        
        # Grid config
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        
        # Fonts
        self.terminal_font = font.Font(family="Courier New", size=11)
        self.bold_font = font.Font(family="Courier New", size=11, weight="bold")
        self.small_font = font.Font(family="Courier New", size=9)
        
        # V-Agent purple theme
        self.colors = {
            'bg': '#1a1b26',
            'text': '#a9b1d6',
            'purple': '#bb9af7',
            'blue': '#7aa2f7',
            'cyan': '#7dcfff',
            'green': '#9ece6a',
            'yellow': '#e0af68',
            'orange': '#ff9e64',
            'red': '#f7768e',
            'magenta': '#bb9af7',
            'dim': '#565f89',
            'user': '#7aa2f7',
            'assistant': '#9ece6a'
        }
        
        # Ollama config
        self.ollama_base = "http://localhost:11434"
        self.model = "qwen2.5-coder:14b"
        self.load_vagent_config()
        
        # Conversation history
        self.conversation_history = []
        self.ollama_available = False
        
        self.setup_ui()
        self.show_welcome()
        
        # Input bindings
        self.input_field.bind('<Return>', self.process_command)
        self.input_field.bind('<Up>', self.history_up)
        self.input_field.bind('<Down>', self.history_down)
        self.input_field.bind('<Tab>', self.autocomplete)
        
        # Command history
        self.command_history = []
        self.history_index = -1
        self.current_input = ""
        
        # Available commands
        self.commands = {
            'help': self.cmd_help,
            'clear': self.cmd_clear,
            'about': self.cmd_about,
            'date': self.cmd_date,
            'echo': self.cmd_echo,
            'whoami': self.cmd_whoami,
            'files': self.cmd_files,
            'agents': self.cmd_agents,
            'security': self.cmd_security,
            'edit': self.cmd_edit,
            'resume': self.cmd_resume,
            'exit': self.cmd_exit,
            'neofetch': self.cmd_neofetch,
            'matrix': self.cmd_matrix,
            'cowsay': self.cmd_cowsay,
            'fortune': self.cmd_fortune,
            'theme': self.cmd_theme,
            'model': self.cmd_model,
            'ask': self.cmd_ask,
            'vagent': self.cmd_vagent,
        }
        
        self.check_ollama()
        self.focus_input()
    
    def load_vagent_config(self):
        """Load V-Agent configuration if available"""
        # Use path relative to this script's location (portable)
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # gui/ -> repo root
        config_path = os.path.join(base_dir, "vagent_config.json")
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
                if 'model' in config:
                    self.model = config['model']
                if 'model_last_used' in config:
                    self.model = config['model_last_used']
            except:
                pass
    
    def check_ollama(self):
        """Check if Ollama is running"""
        try:
            resp = requests.get(f"{self.ollama_base}/api/tags", timeout=3)
            self.ollama_available = (resp.status_code == 200)
        except:
            self.ollama_available = False

    def setup_ui(self):
        # Main frame
        main_frame = tk.Frame(self.root, bg=self.colors['bg'])
        main_frame.grid(row=0, column=0, sticky="nsew", padx=2, pady=2)
        main_frame.grid_rowconfigure(0, weight=1)
        main_frame.grid_columnconfigure(0, weight=1)
        
        # Output area with scroll
        self.output_area = scrolledtext.ScrolledText(
            main_frame,
            bg=self.colors['bg'],
            fg=self.colors['text'],
            insertbackground=self.colors['cyan'],
            font=self.terminal_font,
            wrap=tk.WORD,
            relief=tk.FLAT,
            borderwidth=0,
            padx=15,
            pady=15
        )
        self.output_area.grid(row=0, column=0, sticky="nsew")
        
        # Color tags
        for color_name, color_val in self.colors.items():
            if color_name != 'bg':
                self.output_area.tag_config(color_name, foreground=color_val)
        
        self.output_area.tag_config('bold', font=self.bold_font)
        self.output_area.tag_config('user_prompt', foreground=self.colors['user'])
        self.output_area.tag_config('assistant', foreground=self.colors['assistant'])
        
        # Input frame
        input_frame = tk.Frame(self.root, bg=self.colors['bg'], height=40)
        input_frame.grid(row=1, column=0, sticky="ew", padx=15, pady=(0, 10))
        input_frame.grid_propagate(False)
        
        # Prompt label
        self.prompt_label = tk.Label(
            input_frame,
            text="vagent > ",
            bg=self.colors['bg'],
            fg=self.colors['purple'],
            font=self.bold_font
        )
        self.prompt_label.pack(side=tk.LEFT)
        
        # Input field
        self.input_field = tk.Entry(
            input_frame,
            bg=self.colors['bg'],
            fg=self.colors['text'],
            insertbackground=self.colors['cyan'],
            font=self.terminal_font,
            relief=tk.FLAT,
            borderwidth=0
        )
        self.input_field.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        
        # Status bar
        ollama_status = "Ollama: ONLINE" if self.ollama_available else "Ollama: OFFLINE"
        self.status_bar = tk.Label(
            self.root,
            text=f"{ollama_status}  |  Model: {self.model}  |  V-Agent v0.4  |  /help for commands",
            bg='#16161e',
            fg=self.colors['dim'],
            font=self.small_font,
            anchor=tk.W,
            padx=15,
            pady=3
        )
        self.status_bar.grid(row=2, column=0, sticky="ew")
        
        self.output_area.configure(state='disabled')

    def write(self, text, tag=None, newline=True):
        """Write text to output area"""
        self.output_area.configure(state='normal')
        
        if tag:
            self.output_area.insert(tk.END, text, tag)
        else:
            self.output_area.insert(tk.END, text)
        
        if newline:
            self.output_area.insert(tk.END, '\n')
        
        self.output_area.see(tk.END)
        self.output_area.configure(state='disabled')

    def show_welcome(self):
        """Show welcome message"""
        self.output_area.configure(state='normal')
        self.output_area.delete(1.0, tk.END)
        
        ascii_art = r"""
    +---------------------------------------+
    |                                       |
    |                                       |
    |                                       |
    |        V-AGENT v0.4                   |
    |   Local AI Coding Agent               |
    |                                       |
    |                                       |
    +---------------------------------------+
"""
        for line in ascii_art.split('\n'):
            if 'V-Agent' in line or 'Coding Agent' in line:
                self.write(line, 'purple')
            else:
                self.write(line, 'blue')
        
        self.write("")
        self.write("Welcome to V-Agent Terminal GUI", 'green')
        self.write("")
        
        if self.ollama_available:
            self.write(f"  Status: Connected to Ollama", 'green')
            self.write(f"  Model:  {self.model}", 'green')
        else:
            self.write("  Status: Ollama not detected", 'red')
            self.write("  Start with: ollama serve", 'dim')
        
        self.write("")
        self.write("-" * 70, 'dim')
        self.write("")
        self.write("Quick start:", 'yellow')
        self.write("  Type anything to chat with the AI", 'cyan')
        self.write("  /help        Show all commands", 'cyan')
        self.write("  /model <name>  Change AI model", 'cyan')
        self.write("  /ask <query>   Direct AI question", 'cyan')
        self.write("")
        
        self.output_area.see(tk.END)
        self.output_area.configure(state='disabled')

    def process_command(self, event=None):
        """Process user input"""
        command = self.input_field.get().strip()
        
        if command:
            self.command_history.append(command)
            self.history_index = len(self.command_history)
            
            self.write(f"\nvagent > {command}", 'user_prompt')
            
            self.input_field.delete(0, tk.END)
            
            if command.startswith('/'):
                cmd_parts = command[1:].split()
                cmd_name = cmd_parts[0].lower()
                args = ' '.join(cmd_parts[1:]) if len(cmd_parts) > 1 else ''
                
                if cmd_name in self.commands:
                    try:
                        self.commands[cmd_name](args)
                    except Exception as e:
                        self.write(f"Error: {str(e)}", 'red')
                else:
                    self.write(f"Unknown command: {cmd_name}", 'red')
                    self.write("  Type /help for available commands", 'dim')
            else:
                self.query_ai(command)
        
        self.write("")
        self.focus_input()

    def query_ai(self, message):
        """Send query to Ollama"""
        if not self.ollama_available:
            self.write("Ollama is not available. Start with: ollama serve", 'red')
            return
        
        self.write(f"Sending to {self.model}...", 'dim')
        self.root.update()
        
        self.conversation_history.append({"role": "user", "content": message})
        
        if len(self.conversation_history) > 20:
            self.conversation_history = self.conversation_history[-20:]
        
        def do_query():
            try:
                payload = {
                    "model": self.model,
                    "messages": self.conversation_history,
                    "stream": False,
                    "options": {
                        "temperature": 0.15,
                        "num_ctx": 32768
                    }
                }
                
                resp = requests.post(
                    f"{self.ollama_base}/api/chat",
                    json=payload,
                    timeout=180
                )
                
                if resp.status_code == 200:
                    data = resp.json()
                    response_text = data.get("message", {}).get("content", "")
                    
                    self.conversation_history.append({
                        "role": "assistant",
                        "content": response_text
                    })
                    
                    self.root.after(0, lambda: self.display_ai_response(response_text))
                else:
                    self.root.after(0, lambda: self.write(
                        f"Ollama error: {resp.status_code}", 'red'
                    ))
            except Exception as e:
                self.root.after(0, lambda: self.write(
                    f"Connection error: {str(e)}", 'red'
                ))
        
        threading.Thread(target=do_query, daemon=True).start()
    
    def display_ai_response(self, text):
        """Display AI response"""
        self.write("")
        self.write("-" * 50, 'dim')
        self.write("")
        
        for line in text.split('\n'):
            if line.startswith('```'):
                self.write(line, 'cyan')
            elif line.startswith('#'):
                self.write(line, 'purple')
            else:
                self.write(f"  {line}", 'assistant')
        
        self.write("")
        self.write("-" * 50, 'dim')

    def focus_input(self):
        self.input_field.focus_set()

    def history_up(self, event):
        if self.command_history and self.history_index > 0:
            if self.history_index == len(self.command_history):
                self.current_input = self.input_field.get()
            self.history_index -= 1
            self.input_field.delete(0, tk.END)
            self.input_field.insert(0, self.command_history[self.history_index])

    def history_down(self, event):
        if self.history_index < len(self.command_history) - 1:
            self.history_index += 1
            self.input_field.delete(0, tk.END)
            self.input_field.insert(0, self.command_history[self.history_index])
        elif self.history_index == len(self.command_history):
            self.history_index = len(self.command_history)
            self.input_field.delete(0, tk.END)
            self.input_field.insert(0, self.current_input)

    def autocomplete(self, event):
        current = self.input_field.get().lower()
        if current.startswith('/'):
            search = current[1:]
            matches = [cmd for cmd in self.commands.keys() if cmd.startswith(search)]
            if len(matches) == 1:
                self.input_field.delete(0, tk.END)
                self.input_field.insert(0, f"/{matches[0]} ")
            elif len(matches) > 1:
                self.write("\nMatching commands:", 'dim')
                for match in matches:
                    self.write(f"  /{match}", 'cyan')
        return 'break'

    # ========== Commands ==========
    
    def cmd_help(self, args):
        self.write("+==========================================+", 'blue')
        self.write("|         AVAILABLE COMMANDS               |", 'bold')
        self.write("+==========================================+", 'blue')
        self.write("")
        self.write("  /help          Show this help", 'green')
        self.write("  /clear         Clear screen", 'green')
        self.write("  /ask [text]    Ask the AI", 'green')
        self.write("  /model <name>  Change AI model", 'green')
        self.write("  /vagent        V-Agent info", 'green')
        self.write("  /about         About", 'green')
        self.write("  /date          Show date and time", 'green')
        self.write("  /echo [text]   Echo text", 'green')
        self.write("  /whoami        Current user", 'green')
        self.write("  /files         List files", 'green')
        self.write("  /agents        Create subagents", 'green')
        self.write("  /security      Security review", 'green')
        self.write("  /edit [file]   Edit a file", 'green')
        self.write("  /neofetch      System info", 'green')
        self.write("  /matrix        Matrix effect", 'green')
        self.write("  /cowsay [msg]  Cow says something", 'green')
        self.write("  /fortune       Fortune cookie", 'green')
        self.write("  /theme         Theme info", 'green')
        self.write("  /exit          Exit terminal", 'green')
        self.write("")
        self.write("Tip: Just type to chat with the AI!", 'yellow')

    def cmd_clear(self, args):
        self.output_area.configure(state='normal')
        self.output_area.delete(1.0, tk.END)
        self.output_area.configure(state='disabled')

    def cmd_about(self, args):
        self.write("V-Agent Terminal GUI v2.1", 'purple')
        self.write("Local AI Coding Agent", 'magenta')
        self.write("Built with Python + Tkinter", 'dim')
        self.write("Powered by Ollama", 'dim')

    def cmd_date(self, args):
        now = datetime.datetime.now()
        self.write(f"Date: {now.strftime('%Y-%m-%d')}", 'cyan')
        self.write(f"Time: {now.strftime('%H:%M:%S')}", 'cyan')

    def cmd_echo(self, args):
        if args:
            self.write(args, 'yellow')
        else:
            self.write("Usage: /echo <text>", 'dim')

    def cmd_whoami(self, args):
        username = os.getlogin() if hasattr(os, 'getlogin') else 'user'
        self.write(f"User: {username}", 'green')
        self.write(f"Path: {os.getcwd()}", 'dim')

    def cmd_files(self, args):
        self.write("Files in current directory:", 'yellow')
        try:
            files = os.listdir('.')
            for f in sorted(files)[:20]:
                icon = "[DIR]" if os.path.isdir(f) else "[FILE]"
                size = os.path.getsize(f) if os.path.isfile(f) else 0
                if size > 1024:
                    size_str = f"{size/1024:.1f} KB"
                else:
                    size_str = f"{size} B"
                self.write(f"  {icon} {f:<30} {size_str}", 'text')
            if len(files) > 20:
                self.write(f"  ... and {len(files)-20} more files", 'dim')
        except Exception as e:
            self.write(f"Error: {e}", 'red')
        self.write(f"  {len(files)} items total", 'dim')

    def cmd_agents(self, args):
        self.write("Creating subagents...", 'yellow')
        self.root.update()
        agents = [
            ("analyst", "Code analysis"),
            ("reviewer", "PR review"),
            ("tester", "Unit testing"),
            ("docs", "Documentation"),
        ]
        for name, role in agents:
            time.sleep(0.2)
            self.write(f"  [OK] Agent '{name}' created - {role}", 'green')
            self.root.update()
        self.write("4 subagents active", 'cyan')

    def cmd_security(self, args):
        self.write("Running security review...", 'yellow')
        self.root.update()
        time.sleep(0.5)
        self.write("  [OK] Dependencies: no vulnerabilities", 'green')
        self.write("  [OK] SQL Injection: protected", 'green')
        self.write("  [OK] XSS: no issues found", 'green')
        self.write("  [WARN] 2FA recommended", 'orange')
        self.write("Score: 85/100", 'cyan')

    def cmd_edit(self, args):
        if not args:
            self.write("Usage: /edit <filepath>", 'dim')
            return
        self.write(f"Opening {args}...", 'yellow')
        if os.path.exists(args):
            os.system(f'notepad "{args}"')
            self.write(f"[OK] {args} edited successfully", 'green')
        else:
            self.write(f"File not found: {args}", 'red')

    def cmd_resume(self, args):
        self.write("Recent activity:", 'yellow')
        activities = [
            ("1m ago", "Updated project memory"),
            ("8m ago", "Updated claw'd feet"),
            ("2d ago", "Added new words to spinner"),
            ("1w ago", "Updated unit tests"),
        ]
        for when, what in activities:
            self.write(f"  {when:<12} {what}", 'text')

    def cmd_exit(self, args):
        self.write("Goodbye.", 'magenta')
        self.root.after(1000, self.root.quit)

    def cmd_neofetch(self, args):
        self.write("      ================      ", 'cyan')
        self.write("    ==               ==    ", 'cyan')
        self.write("  ==    ==     ==     ==  ", 'cyan')
        self.write("  ==                   ==  ", 'cyan')
        self.write("  ==    ==     ==     ==  ", 'cyan')
        self.write("    ==               ==    ", 'cyan')
        self.write("      ================      ", 'cyan')
        self.write(f"  OS: Python {sys.version.split()[0]}", 'text')
        self.write(f"  Model: {self.model}", 'text')
        self.write(f"  Ollama: {'ONLINE' if self.ollama_available else 'OFFLINE'}", 'text')
        self.write(f"  Theme: VOIDTUNE Purple", 'text')

    def cmd_matrix(self, args):
        chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&*"
        for _ in range(8):
            line = ''.join(random.choice(chars) for _ in range(60))
            self.write(f"  {line}", 'green')
            self.root.update()
            time.sleep(0.03)

    def cmd_cowsay(self, args):
        if not args:
            args = "V-Agent: local AI, zero telemetry!"
        bubble_width = len(args) + 4
        self.write(" " + "_" * bubble_width, 'yellow')
        self.write(f"< {args} >", 'yellow')
        self.write(" " + "=" * bubble_width, 'yellow')
        self.write("        \\   ^__^", 'yellow')
        self.write("         \\  (oo)\\_______", 'yellow')
        self.write("            (__)\\       )\\/\\", 'yellow')
        self.write("                ||----w |", 'yellow')
        self.write("                ||     ||", 'yellow')

    def cmd_fortune(self, args):
        fortunes = [
            "Today is a great day to code!",
            "A big idea is on its way...",
            "Your commits will be clean and bug-free!",
            "Focus and productivity are in the air!",
            "Time for coffee... and coding!",
            "Bugs? Just undocumented features!",
            "Inspiration is everywhere!",
            "You will solve that tricky bug today!",
        ]
        self.write("[Fortune] " + random.choice(fortunes), 'magenta')

    def cmd_theme(self, args):
        self.write("Current theme: VOIDTUNE Purple", 'purple')
        self.write("Color palette:", 'yellow')
        for color_name in ['purple', 'blue', 'cyan', 'green', 'yellow', 'orange', 'red', 'magenta']:
            self.write(f"  ### {color_name}", color_name)

    def cmd_model(self, args):
        if not args:
            self.write(f"Current model: {self.model}", 'cyan')
            self.write("Usage: /model <model-name>", 'dim')
            return
        
        self.write(f"Switching to {args}...", 'yellow')
        try:
            resp = requests.get(f"{self.ollama_base}/api/tags", timeout=5)
            if resp.status_code == 200:
                models = resp.json().get("models", [])
                model_names = [m["name"] for m in models]
                if args in model_names:
                    self.model = args
                    self.status_bar.config(
                        text=f"Ollama: ONLINE  |  Model: {self.model}  |  V-Agent v0.4  |  /help for commands"
                    )
                    self.write(f"[OK] Model changed to: {self.model}", 'green')
                else:
                    self.write(f"Model '{args}' not found locally", 'red')
                    self.write("Available models:", 'dim')
                    for name in model_names[:10]:
                        self.write(f"  - {name}", 'text')
                    self.write(f"  Pull with: ollama pull {args}", 'dim')
            else:
                self.write("Failed to list models", 'red')
        except Exception as e:
            self.write(f"Error: {e}", 'red')

    def cmd_vagent(self, args):
        self.write("+==========================================+", 'magenta')
        self.write("|         V-AGENT v0.4 + GUI v2.1         |", 'magenta')
        self.write("|      Local AI Coding Agent               |", 'magenta')
        self.write("+==========================================+", 'magenta')
        self.write(f"  Model:  {self.model}", 'text')
        self.write(f"  Ollama: {'ONLINE' if self.ollama_available else 'OFFLINE'}", 'text')
        self.write(f"  Theme:  VOIDTUNE Purple", 'text')
        self.write(f"  Zero telemetry. Your code stays local.", 'dim')
        
        config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "vagent_config.json")  # gui/ -> repo root
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
                hw = config.get("hardware", {})
                if hw:
                    self.write(f"  CPU:  {hw.get('cpu', 'N/A')}", 'text')
                    self.write(f"  RAM:  {hw.get('ram_gb', 'N/A')} GB", 'text')
                    self.write(f"  GPU:  {hw.get('gpu', 'N/A')}", 'text')
                    self.write(f"  VRAM: {hw.get('vram_gb', 'N/A')} GB", 'text')
            except:
                pass

    def cmd_ask(self, args):
        if not args:
            self.write("Usage: /ask <your question>", 'dim')
            return
        self.query_ai(args)


def main():
    root = tk.Tk()
    
    # Center window
    width = 900
    height = 650
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry(f'{width}x{height}+{x}+{y}')
    
    root.minsize(700, 500)
    
    app = VAgentTerminal(root)
    app.focus_input()
    
    root.mainloop()

if __name__ == "__main__":
    main()